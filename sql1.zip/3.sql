Select length, year from MOVIE
WHERE TITLE = LOWER('COAL MINER''S DAUGHTER');