Select address, birthdate from MOVIESTAR
WHERE NAME = LOWER('ALFRED MOLINA');