Select address from STUDIO
WHERE NAME = LOWER('MGM') or NAME = LOWER('DISNEY');


